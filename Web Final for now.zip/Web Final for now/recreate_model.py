"""
Trains a model from clean.csv and saves model.pkl in the workspace.
Tries XGBClassifier first, falls back to RandomForestClassifier if xgboost isn't installed.
This script trains quickly with reduced n_estimators to keep runtime short.
"""
import os
import pickle
import pandas as pd

from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

MODEL_PATH = os.path.join(os.path.dirname(__file__), 'model.pkl')
CSV_PATH = os.path.join(os.path.dirname(__file__), 'clean.csv')

print('CSV_PATH', CSV_PATH)
if not os.path.exists(CSV_PATH):
    raise SystemExit('clean.csv not found in workspace; cannot recreate model.')

# Load data
data = pd.read_csv(CSV_PATH)
if 'disposition' not in data.columns:
    raise SystemExit("Expected a target column named 'disposition' in clean.csv")

X = data.drop('disposition', axis=1).fillna(0)
y = data['disposition']

# Try to use XGBoost if available
try:
    from xgboost import XGBClassifier
    print('Using XGBClassifier')
    model = XGBClassifier(n_estimators=100, learning_rate=0.05, use_label_encoder=False, eval_metric='mlogloss')
except Exception as e:
    print('XGBoost not available, falling back to RandomForestClassifier:', e)
    model = RandomForestClassifier(n_estimators=100, random_state=42)

# Train quickly on a subset if dataset is large
if len(X) > 20000:
    X_train, _, y_train, _ = train_test_split(X, y, train_size=0.2, random_state=42)
    print(f'Dataset large ({len(X)} rows) — training on subset of {len(X_train)} rows')
else:
    X_train, y_train = X, y

model.fit(X_train, y_train)

with open(MODEL_PATH, 'wb') as f:
    pickle.dump(model, f)

print('Saved model to', MODEL_PATH)
print('Model type:', type(model))
