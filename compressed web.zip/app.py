from flask import Flask, request, jsonify
from flask_cors import CORS
import pickle
import pandas as pd
import os

app = Flask(__name__)
CORS(app)

# Load the trained model
# Use a robust path relative to this file and open in read-binary mode
model = None
try:
    model_path = os.path.join(os.path.dirname(__file__), 'model.pkl')
    with open(model_path, 'rb') as f:
        model = pickle.load(f)
    print(f"Model loaded from {model_path}: {type(model)}")
except Exception as e:
    print(f"Error loading model from {model_path}: {e}")
    model = None

# Explicitly set feature names from your CSV header
feature_names = [
    'period',
    'duration',
    'depth',
    'planet_radius',
    'stellar_temperature',
    'stellar_gravity',
    'stellar_radius',
    'magnitude',
    'snr',
    'equilibrium_temp'
]

# Map numeric model outputs to human-friendly labels
# According to your mapping: 1 -> exoplanet, 0 -> candidate of exoplanet, 2 -> not an exoplanet
PREDICTION_LABELS = {
    1: 'exoplanet',
    0: 'candidate of exoplanet',
    2: 'not an exoplanet'
}

@app.route('/predict', methods=['POST'])
def predict():
    if model is None:
        return jsonify({'error': 'Model not loaded!'}), 500

    input_data = request.json
    print(input_data)
    # Determine expected features: prefer the model's feature_names_in_ if available
    try:
        model_features = getattr(model, 'feature_names_in_', None)
        if model_features is not None:
            # feature_names_in_ might be a numpy array; convert to list of strings
            expected_features = [str(x) for x in model_features]
        else:
            expected_features = feature_names
    except Exception:
        expected_features = feature_names

    # Build the input row in the same order as expected_features, filling missing with 0
    data_row = [input_data.get(name, 0) for name in expected_features]
    try:
        df_input = pd.DataFrame([data_row], columns=expected_features)
        # Ensure numeric dtype where possible and fill remaining NaNs with 0
        df_input = df_input.apply(pd.to_numeric, errors='ignore').fillna(0)
        prediction = model.predict(df_input)[0]
        # normalize prediction to a Python int (handles numpy scalar types)
        try:
            pred_int = int(prediction)
        except Exception:
            try:
                pred_int = int(prediction.item())
            except Exception:
                pred_int = prediction

        label = PREDICTION_LABELS.get(pred_int, str(pred_int))
        return jsonify({'prediction': pred_int, 'label': label})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)