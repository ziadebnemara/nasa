import pickle, os
import pandas as pd

p = os.path.join(os.path.dirname(__file__), 'model.pkl')
with open(p,'rb') as f:
    m = pickle.load(f)
print('Model type:', type(m))

# sample input: fill with zeros for simplicity; ensure columns match model.feature_names_in_
cols = [str(x) for x in getattr(m, 'feature_names_in_', ['period','duration','depth','planet_radius','stellar_temperature','stellar_gravity','stellar_radius','magnitude','snr','equilibrium_temp'])]
print('using cols:', cols)
row = [0]*len(cols)
df = pd.DataFrame([row], columns=cols)
print('predicting...')
pred = m.predict(df)[0]
try:
    pred_int = int(pred)
except Exception:
    pred_int = pred
labels = {1: 'exoplanet', 0: 'candidate of exoplanet', 2: 'not an exoplanet'}
print('raw prediction:', pred)
print('mapped:', labels.get(pred_int, str(pred_int)))
