import os
import pickle

model_path = os.path.join(os.path.dirname(__file__), 'model.pkl')
print('Trying to load model from:', model_path)
try:
    with open(model_path, 'rb') as f:
        model = pickle.load(f)
    print('Loaded model type:', type(model))
except Exception as e:
    print('Failed to load model:', e)
