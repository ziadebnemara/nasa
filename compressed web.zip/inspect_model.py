import pickle, os
p = os.path.join(os.path.dirname(__file__), 'model.pkl')
with open(p,'rb') as f:
    m = pickle.load(f)
print('Model type:', type(m))
print('has feature_names_in_?', hasattr(m, 'feature_names_in_'))
print('feature_names_in_:', getattr(m, 'feature_names_in_', None))
print('attrs:', [a for a in dir(m) if 'feature' in a.lower()])
